/*
Template Name: STUDIO - Responsive Bootstrap 4 Admin Template
Version: 1.0.0
Author: Sean Ngu
Website: http://www.seantheme.com/studio/
*/

var handleInitBsFileInput = function() {
	bsCustomFileInput.init();
};


/* Controller
------------------------------------------------ */
$(document).ready(function() {
	handleInitBsFileInput();
});