@extends('layouts.home.homepage')

@section('title', 'Privacy Policy')

@section('content')
    privacy-policy
@endsection
