@extends('layouts.home.homepage')

@section('title', 'Terms & Conditions')

@section('content')
    Terms & Conditions
@endsection
