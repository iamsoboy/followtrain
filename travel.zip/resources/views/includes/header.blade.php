<!-- header -->
<header class="header1 override">
    <div class="container-fluid">
        <div class="top ctrl-wraper2">
            <ul class="left-contact">
                <li><span>want to talk with us</span><a href="tel:09055560002">09055560002</a></li>
            </ul>
            <ul class="right-contact">
                <li>
                    <div>
                        <form>
                            <input type="text" class="hdrsrc" placeholder="search"  />
                            <button class="btn-src" type="submit">

                                <i class="gt-search"></i>
                            </button>
                        </form>
                    </div>
                </li>
                <li>
                    <span>follow us</span>
                    <ul class="hdrsocial">

                        <li class="twitter">
                            <a href="#" class="gt-uniE91B ft-twitter">
                                <svg class="social-circle" width="30" height="30">
                                    <circle class="c" cx="15" cy="15" r="15"></circle>
                                </svg>
                            </a>
                        </li>


                        <li class="facebook">
                            <a href="#" class="gt-uniE914 ft-facebook">
                                <svg class="social-circle" width="30" height="30">
                                    <circle class="c" cx="14" cy="15" r="15"></circle>
                                </svg>
                            </a>
                        </li>

                        <li class="instagram">
                            <a href="#" class="gt-uniE916 ft-instagram">
                                <svg class="social-circle" width="30" height="30">
                                    <circle class="c" cx="14" cy="15" r="15"></circle>
                                </svg>
                            </a>
                        </li>

                    </ul>
                </li>
            </ul>
        </div>
    </div>
</header>
