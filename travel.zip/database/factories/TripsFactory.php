<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Trips;
use Faker\Generator as Faker;

$factory->define(Trips::class, function (Faker $faker) {
    return [
        //
    ];
});
