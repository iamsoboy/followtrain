<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8" />
    <title><?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />

    <!-- ================== BEGIN core-css ================== -->
    <link href="<?php echo e(asset('admin/assets/css/app.min.css')); ?>" rel="stylesheet" />
    <!-- ================== END core-css ================== -->

    <link href="<?php echo e(asset('admin/assets/plugins/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css')); ?>" rel="stylesheet" />

</head>
<body>
<!-- BEGIN #app -->
<div id="app" class="app">
    <?php echo $__env->make('includes.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('includes.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- BEGIN #content -->
<div id="content" class="app-content">
    <h1 class="page-header mb-3">
        Hi, Admin. <small>here's what's happening.</small>
    </h1>

    <?php echo $__env->yieldContent('content'); ?>

</div>
<!-- END #content -->

<!-- BEGIN btn-scroll-top -->
<a href="#" data-click="scroll-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
<!-- END btn-scroll-top -->
</div>
<!-- END #app -->

<!-- ================== BEGIN core-js ================== -->
<script src="<?php echo e(asset('admin/assets/js/app.min.js')); ?>"></script>
<!-- ================== END core-js ================== -->

<!-- ================== BEGIN page-js ================== -->
<script src="<?php echo e(asset('admin/assets/plugins/apexcharts/dist/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/demo/dashboard.demo.js')); ?>"></script>
<!-- required js -->
<script src="<?php echo e(asset('admin/assets/plugins/jquery.maskedinput/src/jquery.maskedinput.js')); ?>"></script>

<script src="<?php echo e(asset('admin/assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>



<!-- ================== END page-js ================== -->
<?php echo $__env->yieldContent('pagescript'); ?>
<!-- ================== BEGIN page-js ================== -->






<!-- ================== END page-js ================== -->

</body>

</html>
<?php /**PATH C:\wamp64\www\travel\resources\views/layouts/admin.blade.php ENDPATH**/ ?>