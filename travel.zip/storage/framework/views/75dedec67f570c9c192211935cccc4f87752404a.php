<?php $__env->startSection('title', 'Booking List'); ?>

<?php $__env->startSection('content'); ?>

    <div class="bst-srcrslt">
        <div class="container-fluid">
            <div class="ctrl-wraper2">

                <div class="cmn-header">
                    <h1>Your best <br />search result</h1>
                    <div class="hdr-rght">
                        <span>changed your mind?</span>
                        <a class="btn-src-agn" href="#">search again</a>
                    </div>
                </div>


                <div class="tickets-infosec">
                    <div class="trip-info">
                        <span class="trip-type">one way</span>
                       <!-- <span> international flight</span> -->
                        <strong><span><?php echo e($daysOfTheWeek); ?>,</span> <?php echo e($travel->departure_date); ?></strong>
                    </div>

                    <div class="venue-log">
                        <div class="venue-map">

                            <svg class="flights-path" viewBox="0 0 345 45"
                                 xmlns="http://www.w3.org/2000/svg" version="1.1"
                                 xmlns:xlink="http://www.w3.org/1999/xlink" >

                                <path id="path1" d="M1 58C1 58 165 -95 345 50"
                                      fill="none" stroke="url(#linegradient)" stroke-width="4"  />

                                <circle cx="345" cy="50" r="6" fill="#1265be"/>
                                <circle cx="0" cy="58" r="6" fill="#ff4981"/>

                                <path id="triangle" d="M12 0c6.623 0 12 5.377 12 12s-5.377 12-12 12-12-5.377-12-12 5.377-12 12-12zm-4.809 13.077l3.627-1.796-3.717-3.17 1.149-.569 6.017 2.031 2.874-1.423c.757-.38 2.009-.278 2.294.296.045.092.065.195.065.306-.002.586-.59 1.381-1.221 1.698l-2.874 1.423-2.031 6.016-1.15.569-.268-4.878-3.626 1.796-.749 1.802-.804.398-.281-2.724-1.996-1.874.804-.399 1.887.498z"
                                      fill="#ff5c8e" fill-rule="evenodd" clip-rule="evenodd" >
                                </path>
                            </svg>
                             <!--<img src="./images/venue-map.svg" alt="map"> -->
                        </div>
                        <div class="venue-desti">
                            <div class="source-city">
                                <span class="city-img"><img src="<?php echo e(asset('home/images/city-img1.jpg')); ?>" alt="img"></span>
                                <div class="city-dtls">
                                    <strong class="citycode"><?php echo e($locationDetails->code); ?></strong>
                                    <span class="city-airport">( <?php echo e($locationDetails->name); ?> )</span>
                                    <!--<span class="ggl-revu">4.4 <i class="gt-star1"></i> 772 <a href="#">Google review</a></span>-->
                                </div>

                            </div>

                            <span class="switch-icon"><img src="<?php echo e(asset('home/images/switch-icon.png')); ?>" alt="img"></span>

                            <div class="destination-city">
                                <span class="city-img"><img src="<?php echo e(asset('home/images/city-img2.jpg')); ?>" alt="img"></span>
                                <div class="city-dtls">
                                    <strong class="citycode"><?php echo e($destinationDetails->code); ?></strong>
                                    <span class="city-airport">( <?php echo e($destinationDetails->name); ?> ) </span>
                                    <!--<span class="ggl-revu">4.4 <i class="gt-star1"></i> 772 <a href="#">Google review</a></span>-->
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="trip-info-footer">
                       <!-- <p>Actual flight time from Indira Gandhi International Airport (DEL), New Delhi, India to London Heathrow Airport (LHR),
                            <br /> London, United Kingdom. Distance between DEL & LHR is approximately 6740 kilometers.</p> -->

                        <a class="btn bdr-rds50 btn-sm btn-chngcity" href="<?php echo e(route('index')); ?>">change city</a>
                    </div>

                </div>

                <div class="dtls-bar">
                    <div class="dtl-header">
                        <h3>Your <br /> details</h3>
                        <p>you can change your details
                            <br /> at any time</p>
                    </div>
                    <ul>
                        <li>
                            <!-- <div class="calendar-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><defs></defs><title>Calendar-Alt</title>
                                    <path id="bottom-left" class="a" d="M7.62,16H6.34A1.21,1.21,0,0,0,5,17v1a1.21,1.21,0,0,0,1.34,1H7.73A1.1,1.1,0,0,0,9,18.05L9,17A1.21,1.21,0,0,0,7.62,16Z"/>
                                    <path id="top-middle" class="a" d="M11,14h2a0.9,0.9,0,0,0,1-.88V12a1,1,0,0,0-1-1H11a1,1,0,0,0-1,1v1.12A0.9,0.9,0,0,0,11,14Z"/>
                                    <rect id="top-left" class="a" x="5" y="11" width="4" height="3" rx="1" ry="1"/>
                                    <rect id="top-right" class="a" x="15" y="11" width="4" height="3" rx="1" ry="1"/>
                                    <path id="bottom-middle" class="a" d="M12.66,16H11.38A1.21,1.21,0,0,0,10,17l0.07,1a1.21,1.21,0,0,0,1.34,1h1.28A1.1,1.1,0,0,0,14,18.05V17A1.21,1.21,0,0,0,12.66,16Z"/>
                                    <path class="container" d="M21.5,3H17V1.06a1,1,0,0,0-1-1H15a1,1,0,0,0-1,1V3H10V1A1,1,0,0,0,9,0H8A1,1,0,0,0,7,1V3H2.5A2.5,2.5,0,0,0,0,5.5v16A2.5,2.5,0,0,0,2.5,24h19A2.5,2.5,0,0,0,24,21.5V5.5A2.5,2.5,0,0,0,21.5,3ZM21,21.13H3V5.94H7v1a1,1,0,0,0,1,1H9a1,1,0,0,0,1-1v-1h4V7a1,1,0,0,0,1,1h1a1,1,0,0,0,1-1V5.94h4V21.13Z"/>
                                <rect id="bottom-right" class="a" x="15.05" y="16" width="3.95" height="3" rx="1" ry="1"/></svg>
                            </div> -->

                            <i class="gt-calendar"></i>
                            <p><?php echo e($fullDate); ?></li>
                        <li>
                            <!-- <i class="gt-user-1"></i> -->
                            <div class="person">
                                <svg viewBox="0 0 68 66" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                        <g transform="translate(2.000000, 2.000000)" fill-rule="nonzero">
                                            <g class="svg-body">
                                                <path d="M61,63.5 L57,63.5 C57,48.3121694 44.6878306,36 29.5,36 C14.3121694,36 2,48.3121694 2,63.5 L-2,63.5 C-2,46.1030304 12.1030304,32 29.5,32 C46.8969696,32 61,46.1030304 61,63.5 Z" fill="#180839"></path>
                                            </g>
                                            <g class="svg-head">
                                                <path d="M29,34 C19.0588745,34 11,25.9411255 11,16 C11,6.0588745 19.0588745,-2 29,-2 C38.9411255,-2 47,6.0588745 47,16 C47,25.9411255 38.9411255,34 29,34 Z M29,30 C36.7319865,30 43,23.7319865 43,16 C43,8.2680135 36.7319865,2 29,2 C21.2680135,2 15,8.2680135 15,16 C15,23.7319865 21.2680135,30 29,30 Z" fill="#180839"></path>
                                                <g class="svg-eyes">
                                                    <line x1="23" y1="10" x2="23" y2="17" stroke-width="3" stroke="#180839"></line>
                                                    <line x1="33" y1="10" x2="33" y2="17" stroke-width="3" stroke="#180839"></line>
                                                </g>
                                            </g>
                                        </g>
                                    </g>
                                </svg>
                            </div>

                            <p><?php echo e($travel->passenger); ?> adults</p>
                        </li>
                        <li>
                            <i class="gt-star"></i>
                            <p><?php echo e($price->ticket_class); ?> class</p>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    </div>

    <!-- We found -->
    <div class="wefound">
        <div class="container-fluid">
            <div class="ctrl-wraper2">
               <!-- <header>
                    <h3>Hey, We found</h3>
                    <span>Some best price for you</span>
                </header> -->

                 

                <!-- <img src="./images/dailyfare-cal.jpg')}}" alt="img" /> -->

               


                <div class="flights-dtls-listing">


                    <?php $__empty_1 = true; $__currentLoopData = $bookingTrips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="listrow">
                            <div class="source-destination">
                                <figure class="cmpny-logo">
                                    <img class="bdr-circle" src="<?php echo e(asset('home/images/airline-logo1.jpg')); ?>" alt="img">
                                    <figcaption><?php echo e($booking->train->name); ?></figcaption>
                                </figure>
                                <div class="src-dst">
                                    <div class="src">
                                        <strong><?php echo e($locationDetails->code); ?></strong>
                                        <!--<span> <i class="gt-right-arrow"></i> 12:25pm</span>-->
                                    </div>
                                    <div class="tracking-line">
                                        <img src="<?php echo e(asset('home/images/tracking-line.png')); ?>" alt="img" />
                                    </div>
                                    <div class="src">
                                        <strong><?php echo e($destinationDetails->code); ?></strong>
                                        <!--<span> <i class="gt-right-arrow"></i> 12:25pm</span>-->
                                    </div>
                                </div>
                            </div>

                            <div class="aditional-features">
                                 <ul>
                                     <li>
                                         <div class="custom-control custom-checkbox">
                                             <i class="gt-right-arrow"></i>
                                             <input type="checkbox" class="custom-control-input" id="rating1" name="time" value="<?php echo e($booking->departure_time); ?>" checked>
                                             <label class="custom-control-label" for="rating1">
                                                 Departure Time <br>
                                                 <div style="font-size: x-large">
                                                     <strong><?php echo e($booking->departure_time); ?></strong>
                                                 </div>

                                             </label>

                                         </div>
                                     </li>
                                     
                                 </ul>
                            </div>


                            <div class="fare-book">
                                <div class="fare">
                                    <strong>&#8358; <?php echo e($price->price); ?></strong>
                                    <span><?php echo e($price->ticket_class); ?> class</span>
                                </div>
                                <form method="post" action="<?php echo e(route('cart.store')); ?>" id="booking-form">
                                    <?php echo csrf_field(); ?>

                                    <div class="booking">
                                        <!--<button class="submit"><span>Book now</span></button>-->
                                        <input type="hidden" name="id" value="<?php echo e(Crypt::encrypt($booking->departure_time)); ?>">
                                        <input type="hidden" name="base" value="<?php echo e(Crypt::encrypt($price->price)); ?>">
                                        <input type="hidden" name="qty" value="<?php echo e(Crypt::encrypt($travel->passenger)); ?>">
                                        <input type="hidden" name="date" value="<?php echo e(Crypt::encrypt($daysOfTheWeek. ' ' .$fullDate)); ?>">
                                        <input type="hidden" name="ticket" value="<?php echo e(Crypt::encrypt($price->ticket_class)); ?>">
                                        <button type="submit" class="btn-book-btn"><span>Book now</span></button>
                                    </div>
                                </form>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <b>Nothing</b>
                        <?php endif; ?>




                    

                    <!-- new row -->

                    <!-- ads row
                    <div class="adsrow">
                        <img src="<?php echo e(asset('home/images/ads3.jpg')); ?>" alt="img" />
                    </div>-->

                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.homepage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\travel\resources\views/home/booking_list.blade.php ENDPATH**/ ?>