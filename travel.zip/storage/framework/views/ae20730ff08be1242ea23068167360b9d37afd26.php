<?php $__env->startSection('title', 'Booking Cart'); ?>

<?php $__env->startSection('content'); ?>

    <!-- section search result -->
    <div class="bst-srcrslt">
        <div class="container-fluid">
            <div class="ctrl-wraper2">

                <?php if(session()->has('success_message')): ?>
                    <div class="alert alert-success mb-6">
                        <strong><?php echo e(session()->get('success_message')); ?></strong>
                    </div>
                <?php endif; ?>
                <?php if(count($errors) > 0 ): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

            <?php $__empty_1 = true; $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="tickets-infosec1 ticket-shapes">
                    <div class="left">
                        <ul class="trip-options">
                            <li class="active">
                                <form action="<?php echo e(route('cart.destroy', Crypt::encrypt($item->rowId))); ?>" method="POST" class="cartform-btn">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-danger btn-lg">Cancel</button>
                                </form>
                            </li>
                            <li> <a>one way</a></li>
                        </ul>
                        <div class="venue-desti">
                            <div class="source-city">
                                <span class="city-img"><img src="<?php echo e(asset('home/images/city-img1.jpg')); ?>" alt="img"></span>
                                <div class="city-dtls">
                                    <strong class="citycode">
                                      <?php if($item->options['location'] == 'Kubwa, Abuja'): ?>
                                        ABJ
                                        <?php elseif($item->options['location'] == 'Rigasa, Kaduna'): ?>
                                        KAD
                                        <?php elseif($item->options['location'] == 'Asham, Kaduna'): ?>
                                        KAD
                                        <?php elseif($item->options['location'] == 'Idu, Kaduna'): ?>
                                        ABJ
                                      <?php endif; ?>
                                    </strong>
                                    <span class="city-airport">( <?php echo e($item->options['location']); ?> )</span>
                                </div>

                            </div>

                            <span class="switch-icon"><img src="<?php echo e(asset('home/images/switch-icon.png')); ?>" alt="img"></span>

                            <div class="destination-city">
                                <span class="city-img"><img src="<?php echo e(asset('home/images/city-img2.jpg')); ?>" alt="img"></span>
                                <div class="city-dtls">
                                    <strong class="citycode">
                                        <?php if($item->options['destination'] == 'Kubwa, Abuja'): ?>
                                            ABJ
                                        <?php elseif($item->options['destination'] == 'Rigasa, Kaduna'): ?>
                                            KAD
                                        <?php elseif($item->options['destination'] == 'Asham, Kaduna'): ?>
                                            KAD
                                        <?php elseif($item->options['destination'] == 'Idu, Kaduna'): ?>
                                            ABJ
                                        <?php endif; ?>
                                    </strong>
                                    <span class="city-airport">( <?php echo e($item->options['destination']); ?> ) </span>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="right">


                        <strong class="booking-date"><span><?php echo e($item->options['date']); ?></strong>
                        <div class="psngr-choice-sec">
                            <p>Passengers choice selection</p>
                            <div class="psngr-dtls">
                                <ul>
                                    <li>
                                        <i class="gt-user-1"></i>
                                        <p><?php echo e($item->qty); ?></p>
                                    </li>
                                    <li>
                                        <i class="gt-star"></i>
                                        <p><?php echo e($item->options['ticket_class']); ?> Class </p>
                                    </li>
                                </ul>
                            </div>
                            <div class="otherdtls">
                                <ul>
                                    <li class="bdr-rds20">
                                        <i class="refresh bdr-rds15 gt-clock"></i>
                                    <?php echo e(\App\Trips::whereId($item->id)->pluck('departure_time')); ?>

                                    </li>
                                </ul>
                                <a class="tkct-available" href="#">Hurry Only 1 Seat available</a>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="alert alert-success mb-6">
                            <strong>You're yet to Book for a Ride</strong>
                        </div>
            <?php endif; ?>

                <div class="pp-details">
                    <div class="psngr-dtls">
                        <h3>Passenger details</h3>
                        <div class="psngr-dtls-box">
                            <h4> <i class="gt-person"></i> Passenger Details</h4>
                            <!--<span class="close">x</span> -->

                            <form id="myform" name="myform" action="<?php echo e(route('pay')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                                <input class="inputype1" type="text" name="name" placeholder="Jean Mcdaniel" />

                                <input class="inputype1" type="text" name="email" placeholder="example@email.com" />

                                <select>
                                    <option>male</option>
                                    <option>female</option>
                                </select>

                                <!--<input class="dob" type="text" placeholder="16 Feb, 1988" /> -->
                                <div class="container">
                                    <div class="row">

                                    </div>

                                </div>
                                <div class="booking">
                                    <button class="btn-book-btn" type="submit">pay now</button>
                                    <!--<a class="btn-chkoutas-guest" href="#">Checkout as guest</a>-->
                                </div>
                            </form>
                        </div>
                        <!--<div class="psngr-dtls-box">
                            <h4> <i class="gt-person"></i> Passenger 02</h4>
                            <span class="close">x</span>
                            <form>
                                <input class="inputname" type="text" placeholder="Jean Mcdaniel" />

                                <select>
                                    <option>male</option>
                                    <option>female</option>
                                </select>

                                <input class="dob" type="text" placeholder="16 Feb, 1988" />

                            </form>
                        </div> -->
                    </div>
                    <div class="pymnt-dtls">
                        <h3>Passenger details</h3>
                        <div class="amt-payble">
                            <strong>Total amount payable</strong>
                            <span class="totpbl-amt">&#8358; <?php echo e(Cart::total()); ?></span>
                            <span class="rate-type-tag">Moderate rate</span>
                            <p>Inclusive of all tax</p>
                        </div>
                        <div class="breakups-wrapper">
                            <div class="breakups">
                                <h5>Breakups</h5>
                                <?php $__currentLoopData = Cart::instance('default')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <strong>Base Fare</strong>
                                <p> Adults (<?php echo e($item->qty); ?> x <?php echo e($item->price); ?>) &#8358; <?php echo e(Cart::priceTotal()); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <strong>Surcharges</strong>
                                <p>Tax(<?php echo e(7.5); ?>)% &#8358; <?php echo e(Cart::tax()); ?></p>
                            </div>

                        <!--    <div class="Cancellation">
                                <h5>Cancellation Fee</h5>

                                <strong>CCU-JFK (Qatar Airways)</strong>
                                <p>$11,284 for cancellations done between 0 hrs - 365 days to departure.* $ 649**</p>
                                <span>*Airline Cancellation Fee.</span>
                                <span>**Let’sGOTraveler</span>
                            </div>-->
                        </div>
                        <div class="pymnt-submit">
                            <a class="btn-loginnow" type="submit">login now</a>
                            <a class="btn-chkoutas-guest" href="#">Checkout as guest</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.homepage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\travel\resources\views/cart/index.blade.php ENDPATH**/ ?>