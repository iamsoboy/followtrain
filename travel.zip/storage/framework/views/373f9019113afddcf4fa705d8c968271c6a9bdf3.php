<?php $__env->startSection('title', 'About Us'); ?>

<?php $__env->startSection('content'); ?>

    <div class="about-company">
        <div class="container-fluid">
            <div class="ctrl-wraper2">

                <div class="about-header">
                    <header>
                        <div class="source">
                            <strong>let's take you there</strong>
                            <span> Jirowo Online Booking</span>
                        </div>

                        <div class="abt-title rellax" data-rellax-speed="-1" data-rellax-percentage="0">
                            <h2>We are Nigeria's  first online rail ticketing platform!</h2>
                        </div>
                    </header>

                    <div class="about-banner-box">
                        <img src="<?php echo e(asset('home/images/asham-station2.jpg')); ?>" alt="">
                    </div>
                </div>

                <div class="about-contant-box">
                    <div class="company-logo">
                        <img src="<?php echo e(asset('home/images/logo.png')); ?>" alt="logo" />
                    </div>
                    <div class="company-dtls py-4 mx-4">
                        <h3>At Afset Solution, we understand that everyone likes easy and affordable travel services, so we provide our customers with a one-stop booking portal for Affordable Rail Tickets, Cargo, Train Station Shuttle Service, Local Hotel Booking and much more</h3>

                        <p>Our portal gives customers the power and the ability to research, plan and book their rail tickets from the comfort of their homes and everywhere they are. We also have an interactive Call Centre and physical travel centres in Kaduna and Abuja with a dedicated travel centre strategically located at each train stations for customers’ convenience.</p>

                        <!--<p>For one year, I have moved, uninhibitedly, as much within as with my feet, like a bird without a nest, flapping my wings in the vast skies, swooping down on parts of the world that beckoned me. A soul without a compass on some days, a spirit that couldn’t be contained on others. Much has been learnt, more has been loved – and the one thing that has remained constant is my desire to keep moving.</p> -->

                    </div>



                </div>

                

            </div>
        </div>
    </div>


    <div class="people-saying">
        <div class="ctrl-wraper2">
            <header>
                <h3>What people <br />Saying</h3>
                <span>Favourite travellers and <br /> Their experience</span>
            </header>

            <div class="review-slider slider">
                <div class="rs-item">
                    <div class="rs-thumb">
                        <img src="<?php echo e(asset('homes/images/people1.png')); ?>" alt="img" />
                    </div>
                    <div class="rs-content">
                        <i class="gt-heart"></i>
                        <strong>Johanna Gross</strong>
                        <span><img src="<?php echo e(asset('home/images/icons/quote.svg')); ?>" alt="quote" /></span>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                    </div>
                </div>

                <div class="rs-item">
                    <div class="rs-thumb">
                        <img src="<?php echo e(asset('homes/images/people2.png')); ?>" alt="img" />
                    </div>
                    <div class="rs-content">
                        <i class="gt-heart"></i>
                        <strong>Johanna Gross</strong>
                        <span><img src="<?php echo e(asset('home/images/icons/quote.svg')); ?>" alt="quote" /></span>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                    </div>
                </div>

                <div class="rs-item">
                    <div class="rs-thumb">
                        <img src="<?php echo e(asset('homes/images/people3.png')); ?>" alt="img" />
                    </div>
                    <div class="rs-content">
                        <i class="gt-heart"></i>
                        <strong>Johanna Gross</strong>
                        <span><img src="<?php echo e(asset('home/images/icons/quote.svg')); ?>" alt="quote" /></span>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                    </div>
                </div>

                <div class="rs-item">
                    <div class="rs-thumb">
                        <img src="<?php echo e(asset('homes/images/people4.png')); ?>" alt="img" />
                    </div>
                    <div class="rs-content">
                        <i class="gt-heart"></i>
                        <strong>Johanna Gross</strong>
                        <span><img src="<?php echo e(asset('home/images/icons/quote.svg')); ?>" alt="quote" /></span>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                    </div>
                </div>

                <div class="rs-item">
                    <div class="rs-thumb">
                        <img src="<?php echo e(asset('homes/images/people5.png')); ?>" alt="img" />
                    </div>
                    <div class="rs-content">
                        <i class="gt-heart"></i>
                        <strong>Johanna Gross</strong>
                        <span><img src="<?php echo e(asset('home/images/icons/quote.svg')); ?>" alt="quote" /></span>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                    </div>
                </div>

                <div class="rs-item">
                    <div class="rs-thumb">
                        <img src="<?php echo e(asset('homes/images/people6.png')); ?>" alt="img" />
                    </div>
                    <div class="rs-content">
                        <i class="gt-heart"></i>
                        <strong>Johanna Gross</strong>
                        <span><img src="<?php echo e(asset('home/images/icons/quote.svg')); ?>" alt="quote" /></span>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                    </div>
                </div>

                <div class="rs-item">
                    <div class="rs-thumb">
                        <img src="<?php echo e(asset('homes/images/people1.png')); ?>" alt="img" />
                    </div>
                    <div class="rs-content">
                        <i class="gt-heart"></i>
                        <strong>Johanna Gross</strong>
                        <span><img src="<?php echo e(asset('home/images/icons/quote.svg')); ?>" alt="quote" /></span>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                    </div>
                </div>

            </div>
        </div>
    </div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.homepage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\travel\resources\views/home/about.blade.php ENDPATH**/ ?>