<!-- nav menu -->
<div class="cntrlogo-navmenu clearfix">
    <div class="container-fluid">
        <div class="ctrl-wraper2">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand logo-center" href="<?php echo e(route('index')); ?>">
                     <img src="<?php echo e(asset('home/images/logo.png')); ?>" alt="logo" />
                    <span class="animated-logo"></span>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <button type="button" class="partial-nav-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('index')); ?>">Home </a>
                        </li>
                        <li class="nav-item <?php echo e(Request::is('about') ? 'active' : 'none'); ?>">
                            <a class="nav-link" href="<?php echo e(route('about.index')); ?>">about us</a>
                        </li>
                        <li class="nav-item <?php echo e(Request::is('services') ? 'active' : 'none'); ?>">
                            <a class="nav-link" href="<?php echo e(route('services.index')); ?>">services</a>
                        </li>
                        <li class="nav-item <?php echo e(Request::is('blog') ? 'active' : 'none'); ?>">
                            <a class="nav-link" href="<?php echo e(route('blog.index')); ?>">news</a>
                        </li>
                        <li class="nav-item <?php echo e(Request::is('contact-us') ? 'active' : 'none'); ?>">
                            <a class="nav-link" href="<?php echo e(route('contact.index')); ?>">contact</a>
                        </li>
                        <li class="nav-item <?php echo e(Request::is('login') ? 'active' : 'none'); ?>">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">login</a>
                        </li>
                        <li class="nav-item <?php echo e(Request::is('offers') ? 'active' : 'none'); ?>">
                            <a class="nav-link" href="<?php echo e(route('offers.index')); ?>">offers</a>
                        </li>
                        <li class="nav-item">

                        </li>

                    </ul>
                </div>
            </nav>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\travel\resources\views/includes/mainmenu.blade.php ENDPATH**/ ?>